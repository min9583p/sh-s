import pyttsx3

engine = pyttsx3.init()

voices = engine.getProperty('voices')

engine.setProperty('rate', 210)
engine.setProperty('volume', 1.0)
engine.setProperty("voice", voices[0].id)

engine.save_to_file("How do you do?", "output.mp3")
engine.runAndWait()