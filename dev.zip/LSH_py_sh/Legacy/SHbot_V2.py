#main.py
from game import *
from user import *
import asyncio, discord
from discord import Member
from discord.utils import get
from discord.ext import commands
from discord.commands import *
import random
import zlib
import sys

bot = discord.Bot()

@bot.event
async def on_ready():
    channel = bot.get_channel(1008004079743672432)
    print("We have loggedd in as {0.user}".format(bot))
        
@bot.slash_command(name = '안녕', description = '간단한 인사기능')
async def 안녕(ctx, name: str = None):
    name = name or ctx.author.name
    await ctx.respond(f"안녕 {name}!")

@bot.slash_command(name = '도움말', description = '말그대로')
async def 도움(ctx):
    embed = discord.Embed(title = "서하봇", description = "V2", color = 0x6E17E3) 
    embed.add_field(name = "❓도움", value = "도움말을 봅니다", inline = False)
    embed.add_field(name = "🎲주사위", value = "주사위를 굴려 봇과 대결합니다", inline = False)
    embed.add_field(name = "📋내정보", value = "자신의 정보를 확인합니다", inline = False)
    embed.add_field(name = "🔎정보 [대상]", value = "멘션한 [대상]의 정보를 확인합니다", inline = False)
    embed.add_field(name = "📨송금 [대상] [돈]", value = "멘션한 [대상]에게 [돈]을 보냅니다", inline = False)
    embed.add_field(name = "🎰도박 [돈]", value = "[돈]을 걸어 도박을 합니다. 올인도 가능합니다", inline = False)
    embed.add_field(name = "🧧용돈", value = "랜덤으로 용돈을 지급한다", inline = False)
    embed.add_field(name = "💳환전 [미무포인트]", value = "미무포인트로 환전한다. ex)서하야 환전 10000 | 10만원 = 1만 포인트", inline = False)
    await ctx.send(embed=embed)

@bot.slash_command(name = '고급도움말', description = '서하 전용')
@commands.has_any_role(1004689605305585704, 998046067964776578)
async def 고급(ctx):
    embed = discord.Embed(title = "서하봇", description = "V2", color = 0x6E17E3) 
    embed.add_field(name = "❓도움", value = "도움말을 봅니다", inline = False)
    embed.add_field(name = "🎲주사위", value = "주사위를 굴려 봇과 대결합니다", inline = False)
    embed.add_field(name = "📋내정보", value = "자신의 정보를 확인합니다", inline = False)
    embed.add_field(name = "🔎정보 [대상]", value = "멘션한 [대상]의 정보를 확인합니다", inline = False)
    embed.add_field(name = "📨송금 [대상] [돈]", value = "멘션한 [대상]에게 [돈]을 보냅니다", inline = False)
    embed.add_field(name = "🎰도박 [돈]", value = "[돈]을 걸어 도박을 합니다. 올인도 가능합니다", inline = False)
    embed.add_field(name = "🧧용돈", value = "랜덤으로 용돈을 지급한다(쿨타임 1시간)", inline = False)
    embed.add_field(name = "💳환전 [미무포인트]", value = "미무포인트로 환전한다. ex)서하야 환전 10000 | 10만원 = 1만 포인트", inline = False)
    embed.add_field(name = "========================", value = "관리자 전용 커맨드", inline = False)
    embed.add_field(name = "🧧지급 [대상] [돈]", value = "멘션한 [대상]에게 [돈]을 지급합니다", inline = False)
    embed.add_field(name = "✨경험치 [대상] [경험치]", value = "멘션한 [대상]에게 [경험치]을 지급합니다", inline = False)
    embed.add_field(name = "🎟️레벨 [대상] [레벨]", value = "멘션한 [대상]에게 [레벨]을 지급합니다", inline = False)
    embed.add_field(name = "💸차감 [대상] [돈]", value = "멘션한 [대상]에게서 [돈]을 차감합니다", inline = False)
    embed.set_footer(text="주인장")
    channel = bot.get_channel(997116215942193244)
    await channel.send(embed=embed)

@bot.slash_command(name = '원무과', description = '원무과 전용 도움말')
@commands.has_any_role(1004689605305585704, 1004688539914608640, 998046067964776578, 1004771045091323944)
async def 원무과(ctx):
    embed = discord.Embed(title = "원무과 전용 커맨드", description = "이거 쓰느라 머리아파요", color = 0x6E17E3) 
    embed.add_field(name = "========================", value = "원무과 전용 커맨드", inline = False)
    embed.add_field(name = "📢a [대상]", value = "원무과 전용 | 병동에 [대상]을 멘션하여 환영멘트를 보냅니다", inline = False)
    embed.add_field(name = "📣b [대상] [대상1]", value = "원무과 전용 | 병동에 [대상]~[대상1]을 멘션하여 환영멘트를 보냅니다", inline = False)
    embed.add_field(name = "📢c [대상] [대상1] [대상2]", value = "원무과 전용 | 병동에 [대상]~[대상2]을 멘션하여 환영멘트를 보냅니다", inline = False)
    embed.add_field(name = "📣d [대상] [대상1] [대상2] [대상3]", value = "원무과 전용 | 병동에 [대상]~[대상3]을 멘션하여 환영멘트를 보냅니다", inline = False)
    embed.add_field(name = "🆘e", value = "원무과 전용 | 안내중 문제 발생시 보안팀 호출", inline = False)
    embed.set_footer(text="주인장")
    channel = bot.get_channel(1005089714266701925)
    await channel.send(embed=embed)

@bot.slash_command(name = '간호사', description = '간호사 전용 도움말')
@commands.has_any_role(1004688954089537667, 1004688539914608640, 998046067964776578, 1004771045091323944)
async def 간호사(ctx):
    embed = discord.Embed(title = "간호사 전용 커맨드", description = "이거 쓰느라 머리아파요", color = 0x6E17E3) 
    embed.add_field(name = "========================", value = "간호사 전용 커맨드", inline = False)
    embed.add_field(name = "📢f [대상]", value = "간호사 전용 | 병동에 [대상]을 멘션하여 환영멘트를 보냅니다", inline = False)
    embed.add_field(name = "📣g [대상] [대상1]", value = "간호사 전용 | 병동에 [대상]~[대상1]을 멘션하여 환영멘트를 보냅니다", inline = False)
    embed.add_field(name = "📢h [대상] [대상1] [대상2]", value = "간호사 전용 | 병동에 [대상]~[대상2]을 멘션하여 환영멘트를 보냅니다", inline = False)
    embed.add_field(name = "📣i [대상] [대상1] [대상2] [대상3]", value = "간호사 전용 | 병동에 [대상]~[대상3]을 멘션하여 환영멘트를 보냅니다", inline = False)
    embed.set_footer(text="주인장")
    channel = bot.get_channel(1005089714266701925)
    await channel.send(embed=embed)

@bot.slash_command(name = '보안팀', description = '보안팀 전용 도움말')
@commands.has_any_role(1004688567613784175, 1004688539914608640, 1004689605305585704, 998046067964776578, 1004771045091323944)
async def 보안팀(ctx):
    embed = discord.Embed(title = "보안팀 전용 커맨드", description = "이거 쓰느라 머리아파요", color = 0x6E17E3) 
    embed.add_field(name = "========================", value = "보안팀 전용 커맨드", inline = False)
    embed.add_field(name = "⚠️j [대상] [횟수] [번호]", value = "보안팀 전용 | 중환자실에 [대상]을 멘션하여 [번호]에 해당하는 주의를 [횟수]만큼 지급합니다", inline = False)
    embed.add_field(name = "🚫k [대상] [횟수] [번호]", value = "보안팀 전용 | 중환자실에 [대상]을 멘션하여 [번호]에 해당하는 경고를 [횟수]만큼 지급합니다", inline = False)
    embed.add_field(name = "🏴l [대상] [번호]", value = "보안팀 전용 | 영안실에 [대상]을 멘션하여 [번호]에 해당하는 사유를 작성합니다", inline = False)
    embed.set_footer(text="주인장")
    channel = bot.get_channel(1005089714266701925)
    await channel.send(embed=embed)

@bot.slash_command(name = '정신과', description = '정신과 전용 도움말')
@commands.has_any_role(1004688920694501406, 1004688539914608640, 1004689605305585704, 998046067964776578, 1004771045091323944)
async def 정신과(ctx):
    embed = discord.Embed(title = "정신과 전용 커맨드", description = "이거 쓰느라 머리아파요", color = 0x6E17E3) 
    embed.add_field(name = "========================", value = "정신과 전용 커맨드", inline = False)
    embed.add_field(name = "🆘p", value = "정신과 전용 | 상담중 문제 발생시 보안팀 호출", inline = False)
    embed.set_footer(text="주인장")
    channel = bot.get_channel(1005089714266701925)
    await channel.send(embed=embed)

@bot.slash_command(name = '외과', description = '외과 전용 도움말')
@commands.has_any_role(1004688920694501406, 1004688539914608640, 1004689605305585704, 998046067964776578, 1004771045091323944)
async def 외과(ctx):
    embed = discord.Embed(title = "외과 전용 커맨드", description = "이거 쓰느라 머리아파요", color = 0x6E17E3) 
    embed.add_field(name = "========================", value = "외과 전용 커맨드", inline = False)
    embed.add_field(name = "🔔t [대상] [담당자]", value = "외과 전용 | 에블핑과 [대상] [담당자]을 언급한다", inline = False)
    embed.set_footer(text="주인장")
    channel = bot.get_channel(1005089714266701925)
    await channel.send(embed=embed)

@bot.slash_command(name = '주사위', description = '주사위를 굴릴수 있다!')
async def 주사위(ctx):
    result, _color, bot1, bot2, user1, user2, a, b = dice()

    embed = discord.Embed(title = "주사위 게임 결과", description = "\n", color = _color)
    embed.add_field(name = "서하봇의 숫자 " + bot1 + "+" + bot2, value = ":game_die: " + a, inline = False)
    embed.add_field(name = ctx.author.name+"의 숫자 " + user1 + "+" + user2, value = ":game_die: " + b, inline = False)
    embed.set_footer(text="결과: " + result)
    await ctx.send(embed=embed)

@bot.slash_command(name = '도박', description = '도박상담은 1366')
async def 도박(ctx, money):
    userExistance, userRow = checkUser(ctx.author.name, ctx.author.id)
    win = gamble()
    result = ""
    betting = 0
    _color = 0x000000
    if userExistance:
        print("DB에서 ", ctx.author.name, "을 찾았습니다.")
        cur_money = getMoney(ctx.author.name, userRow)

        if money == "올인":
            betting = cur_money
            if win:
                result = "성공"
                _color = 0x00ff56
                print(result)

                modifyMoney(ctx.author.name, userRow, int(0.5*betting))

            else:
                result = "실패"
                _color = 0xFF0000
                print(result)

                modifyMoney(ctx.author.name, userRow, -int(betting))
                addLoss(ctx.author.name, userRow, int(betting))

            embed = discord.Embed(title = "🎰도박 결과🎰", description = result, color = _color)
            embed.add_field(name = "🪙배팅금액", value = betting, inline = False)
            embed.add_field(name = "💰현재 자산", value = getMoney(ctx.author.name, userRow), inline = False)
            embed.add_field(name = "도박은 질병입니다.", value = ctx.author.mention, inline = False)
            embed.set_footer(text="도박상담 1336")

            await ctx.send(embed=embed)
            
        elif int(money) >= 10:
            if cur_money >= int(money):
                betting = int(money)
                print("배팅금액: ", betting)
                print("")

                if win:
                    result = "성공"
                    _color = 0x00ff56
                    print(result)

                    modifyMoney(ctx.author.name, userRow, int(0.5*betting))

                else:
                    result = "실패"
                    _color = 0xFF0000
                    print(result)

                    modifyMoney(ctx.author.name, userRow, -int(betting))
                    addLoss(ctx.author.name, userRow, int(betting))

                embed = discord.Embed(title = "🎰도박 결과🎰", description = result, color = _color)
                embed.add_field(name = "🪙배팅금액", value = betting, inline = False)
                embed.add_field(name = "💰현재 자산", value = getMoney(ctx.author.name, userRow), inline = False)
                embed.add_field(name = "도박은 질병입니다.", value = ctx.author.mention, inline = False)
                embed.set_footer(text="도박상담 1336")

                await ctx.send(embed=embed)

            else:
                print("돈이 부족합니다.")
                print("배팅금액: ", money, " | 현재자산: ", cur_money)
                await ctx.send("돈이 부족합니다. 현재자산: " + str(cur_money))
        else:
            print("배팅금액", money, "가 10보다 작습니다.")
            await ctx.send("10원 이상만 배팅 가능합니다.")
    else:
        print("DB에서 ", ctx.author.name, "을 찾을 수 없습니다")
        await ctx.send("도박은 회원가입 후 이용 가능합니다.")

    print("------------------------------\n")

@bot.slash_command(name = '랭킹', description = '누가누가 레벨이 높을까?')
async def 랭킹(ctx):
    rank = ranking()
    embed = discord.Embed(title = "🏆레벨 랭킹", description = "", color = 0x4A44FF)

    for i in range(0,len(rank)):
        if i%2 == 0:
            name = rank[i]
            lvl = rank[i+1]
            embed.add_field(name = str(int(i/2+1))+"위 "+name, value ="🎟️레벨: "+str(lvl), inline=False)

    await ctx.send(embed=embed) 

@bot.slash_command(name = '등록', description = '강제로 회원등록!')
@commands.has_any_role(1004689605305585704, 998046067964776578)
async def 등록(ctx, 
고유아이디:Option(discord.User,'멤버의 고유아이디를 입력해주세요')):
    print("회원가입이 가능한지 확인합니다.")
    userExistance, userRow = checkUser(고유아이디.name, 고유아이디.id)
    if userExistance:
        print("DB에서 ", 고유아이디.name, "을 찾았습니다.")
        print("------------------------------\n")
        await ctx.send("이미 등록하셨습니다.")
    else:
        print("DB에서 ", 고유아이디.name, "을 찾을 수 없습니다")
        print("")

        Signup(고유아이디.name, 고유아이디.id)

        print("회원가입이 완료되었습니다.")
        print("------------------------------\n")
        await ctx.send(f'{고유아이디.mention}님의 추가 등록이 완료되었습니다. 즐거운 병원생활하세요.')

@bot.slash_command(name = '번호표', description = '안내를 받고싶다면 번호표를 뽑아봐!')
@commands.has_any_role(1004739278720483418)
async def 번호표(ctx):
    print("회원가입이 가능한지 확인합니다.")
    userExistance, userRow = checkUser(ctx.author.name, ctx.author.id)
    if userExistance:
        print("DB에서 ", ctx.author.name, "을 찾았습니다.")
        print("------------------------------\n")
        await ctx.send(f'번호표가 발급되었습니다.\n\n<@&1004688586093887528>\n{ctx.author.name}님의 안내를 도와주세요')
    else:
        print("DB에서 ", ctx.author.name, "을 찾을 수 없습니다")
        print("")

        Signup(ctx.author.name, ctx.author.id)

        print("회원가입이 완료되었습니다.")
        print("------------------------------\n")
        await ctx.send(f'번호표가 발급되었습니다.\n\n<@&1004688586093887528>\n{ctx.author.name}님의 안내를 도와주세요')

@bot.slash_command(name = '탈퇴', description = '강제로 회원을 탈퇴 시킵니다.')
@commands.has_any_role(1004689605305585704, 998046067964776578)
async def 탈퇴(ctx, user: discord.User):
    print("탈퇴가 가능한지 확인합니다.")
    userExistance, userRow = checkUser(user.name, user.id)
    if userExistance:
        DeleteAccount(userRow)
        print("탈퇴가 완료되었습니다.")
        print("------------------------------\n")

        await ctx.send("탈퇴가 완료되었습니다.")
    else:
        print("DB에서 ", user.name, "을 찾을 수 없습니다")
        print("------------------------------\n")

        await ctx.send("등록되지 않은 사용자입니다.")

@bot.slash_command(name = '내정보', description = '나의 정보를 확인 할 수 있어!')
async def 내정보(ctx):
    userExistance, userRow = checkUser(ctx.author.name, ctx.author.id)

    if not userExistance:
        print("DB에서 ", ctx.author.name, "을 찾을 수 없습니다")
        print("------------------------------\n")
        await ctx.send("회원가입 후 자신의 정보를 확인할 수 있습니다.")
    else:
        level, exp, money, loss = userInfo(userRow)
        rank = getRank(userRow)
        userNum = checkUserNum()
        expToUP = level*level + 6*level
        boxes = int(exp/expToUP*20)
        print("------------------------------\n")
        embed = discord.Embed(title="📋유저 정보", description = ctx.author.name, color = 0x62D0F6)
        embed.add_field(name = "🎟️레벨", value = level)
        embed.add_field(name = "🏆순위", value = str(rank) + "/" + str(userNum))
        embed.add_field(name = "✨XP: " + str(exp) + "/" + str(expToUP), value = boxes * ":blue_square:" + (20-boxes) * ":white_large_square:", inline = False)
        embed.add_field(name = "💰보유 자산", value = money, inline = False)
        embed.add_field(name = "💸도박으로 날린 돈", value = loss, inline = False)

        await ctx.send(embed=embed)

@bot.slash_command(name = '정테', description = '정보가 궁금한 사람이 있어?')
async def 정테(ctx, 
    user:Option(discord.Member, "원하는 환자를 태그해줘!")):
    userExistance, userRow = checkUser(user.name, user.id)

    if not userExistance:
        print("DB에서 ", user.name, "을 찾을 수 없습니다")
        print("------------------------------\n")
        await ctx.send(user.name  + " 은(는) 등록되지 않은 사용자입니다.")
    else:
        level, exp, money, loss = userInfo(userRow)
        rank = getRank(userRow)
        userNum = checkUserNum()
        print("------------------------------\n")
        embed = discord.Embed(title="🔎유저 정보", description = user.name, color = 0x62D0F6)
        embed.add_field(name = "🎟️레벨", value = level)
        embed.add_field(name = "✨경험치", value = str(exp) + "/" + str(level*level + 6*level))
        embed.add_field(name = "🏆순위", value = str(rank) + "/" + str(userNum))
        embed.add_field(name = "💰보유 자산", value = money, inline = False)
        embed.add_field(name = "💸도박으로 날린 돈", value = loss, inline = False)

        await ctx.send(embed=embed)

@bot.slash_command(name = '정보', description = '정보가 궁금한 사람이 있어?')
async def 정보(ctx, user: discord.User):
    userExistance, userRow = checkUser(user.name, user.id)
    if not userExistance:
        print("DB에서 ", user.name, "을 찾을 수 없습니다")
        print("------------------------------\n")
        await ctx.send(user.name  + " 은(는) 등록되지 않은 사용자입니다.")
    else:
        level, exp, money, loss = userInfo(userRow)
        rank = getRank(userRow)
        userNum = checkUserNum()
        print("------------------------------\n")
        embed = discord.Embed(title="🔎유저 정보", description = user.name, color = 0x62D0F6)
        embed.add_field(name = "🎟️레벨", value = level)
        embed.add_field(name = "✨경험치", value = str(exp) + "/" + str(level*level + 6*level))
        embed.add_field(name = "🏆순위", value = str(rank) + "/" + str(userNum))
        embed.add_field(name = "💰보유 자산", value = money, inline = False)
        embed.add_field(name = "💸도박으로 날린 돈", value = loss, inline = False)

        await ctx.send(embed=embed)

@bot.slash_command(name = '송금', description = '누구한테 돈을 보낼래?')
async def 송금(ctx, user: discord.User, money):
    print("송금이 가능한지 확인합니다.")
    senderExistance, senderRow = checkUser(ctx.author.name, ctx.author.id)
    receiverExistance, receiverRow = checkUser(user.name, user.id)

    if not senderExistance:
        print("DB에서", ctx.author.name, "을 찾을수 없습니다")
        print("------------------------------\n")
        await ctx.send("회원가입 후 송금이 가능합니다.")
    elif not receiverExistance:
        print("DB에서 ", user.name, "을 찾을 수 없습니다")
        print("------------------------------\n")
        await ctx.send(user.name  + " 은(는) 등록되지 않은 사용자입니다.")
    else:
        print("송금하려는 돈: ", money)

        s_money = getMoney(ctx.author.name, senderRow)
        r_money = getMoney(user.name, receiverRow)

        if s_money >= int(money) and int(money) != 0:
            print("돈이 충분하므로 송금을 진행합니다.")
            print("")

            remit(ctx.author.name, senderRow, user.name, receiverRow, money)

            print("송금이 완료되었습니다. 결과를 전송합니다.")

            embed = discord.Embed(title="송금 완료📨", description = "송금된 돈: " + money, color = 0x77ff00)
            embed.add_field(name = "보낸 사람: " + ctx.author.name, value = "현재 자산: " + str(getMoney(ctx.author.name, senderRow)))
            embed.add_field(name = "→", value = ":moneybag:")
            embed.add_field(name="받은 사람: " + user.name, value="현재 자산: " + str(getMoney(user.name, receiverRow)))
                    
            await ctx.send(embed=embed)
        elif int(money) == 0:
            await ctx.send("0원을 보낼 필요는 없죠")
        else:
            print("돈이 충분하지 않습니다.")
            print("송금하려는 돈: ", money)
            print("현재 자산: ", s_money)
            await ctx.send("돈이 충분하지 않습니다. 현재 자산: " + str(s_money))

        print("------------------------------\n")


@bot.slash_command(name = 'reset', description = '회원정보 초기화')
@commands.has_any_role(998046067964776578)
async def reset(ctx):
    resetData()

@bot.slash_command(name = '환전', description = '미무포인트로 환전하고 싶어?')
async def 환전(ctx, text):
    channel = bot.get_channel(1008380068915060767)
    await channel.send(f"<@&998046067964776578>\n\n{ctx.author.mention}님이 {text}만큼의 환전을 요청하셨습니다!")

@bot.slash_command(name = '용돈', description = '용돈받고싶은사람~')
@commands.cooldown(1, 3600, commands.BucketType.user)
async def 용돈(ctx):
    channel = bot.get_channel(1006571303211372544)
    rmm = [10, 100, 500, 1000, 50, 500, 5000, 2000, 2500, 300, 1500, 10000, 100000, 10, 100, 500, 1000, 50, 500, 5000, 2000, 2500, 300, 1500, 10, 100, 500, 1000, 50, 500, 5000, 2000, 2500, 300, 1500, 10, 100, 500, 1000, 50, 500, 10, 100, 500, 1000, 50, 500]
    rm = random.choice(rmm)
    await channel.send(f'{ctx.author.mention}님에게 성공적으로 {rm}원을 지급하였습니다.\n\n다음 사용 가능시간까지 1시간 남았습니다.\n쿨타임 이전에는 해당 명령어에 반응하지 않습니다.')
    user, row = checkUser(ctx.author.name, ctx.author.id)
    addMoney(row, int(rm))
    print("MONEY add Success")

@bot.slash_command(name = '지급', description = '돈을 주자!')
@commands.has_any_role(1004689605305585704, 998046067964776578)
async def 지급(ctx, user: discord.User, money):
    await ctx.send(user.mention + "님에게 성공적으로 " + money + "원을 지급하였습니다.")
    user, row = checkUser(user.name, user.id)
    addMoney(row, int(money))
    print("MONEY add Success")

@bot.slash_command(name = '경험치', description = '누구한테 경험치를 줘볼까?')
@commands.has_any_role(1004689605305585704, 998046067964776578)
async def 경험치(ctx, user: discord.User, exp):
    await ctx.send(user.mention + "님에게 성공적으로 " + exp + "경험치를 지급하였습니다.")
    user, row = checkUser(user.name, user.id)
    addExp(row, int(exp))
    print("EXP add Success")

@bot.slash_command(name = '레벨', description = '레벨을 주고싶어?')
@commands.has_any_role(1004689605305585704, 998046067964776578)
async def 레벨(ctx, user: discord.User, lvl):
    await ctx.send(user.mention + '님에게 성공적으로 ' + lvl + '레벨을 지급하였습니다.')
    user, row = checkUser(user.name, user.id)
    adjustlvl(row, int(lvl))
    print("LEVEL add Success")

@bot.slash_command(name = '차감', description = '돈을 뺏자!')
@commands.has_any_role(1004689605305585704, 998046067964776578)
async def 차감(ctx, user: discord.User, money):
    await ctx.send(f'{user.mention}님의 자산을 성공적으로 {money}원 차감하였습니다.')
    user, row = checkUser(user.name, user.id)
    modifyMoney(user, row, -int(money))
    print("MONEY min Success")
    

@bot.event
async def on_message(message):
    if message.author == bot.user:
        return
    else:
        userExistance, userRow = checkUser(message.author.name, message.author.id)
        channel = bot.get_channel(1005349277947670528)
        if userExistance:
            levelUp, lvl = levelupCheck(userRow)
            if levelUp:
                print(message.author, "가 레벨업 했습니다")
                print("")
                embed = discord.Embed(title = "🧪약물치료🧪", description = "", color = 0x00A260)
                embed.set_footer(text = message.author.name + " 님이 약물치료 " + str(lvl) + "회를 받으셨습니다")
                await channel.send(embed=embed)
            else:
                modifyExp(userRow, 1)
                addMoney(userRow, int(10))
                print("------------------------------\n")

@bot.slash_command(name = '점검', description = '점검 시간을 알리는거야!')
@commands.has_any_role(998046067964776578)
async def 점검(ctx, text1, text2):
    channel = bot.get_channel(1006571303211372544)
    channel1 = bot.get_channel(1005089714266701925)
    embed = discord.Embed(title="🚧 점검 공지 🚧", description = " " ,color = 0xFFC300)
    embed.add_field(name = "일시 점검 안내", value = "서하봇의 점검이 진행 될 예정입니다.", inline = False)
    embed.add_field(name = "점검 시간", value = text1 +" ~ "+ text2+"까지", inline = False)
    embed.add_field(name = "점검시 유의사항", value = "주사위, 도박, 정보 등 전체 기능 일시 마비", inline = False)
    
    embed1 = discord.Embed(title="🚧 점검 공지 🚧", description = " " ,color = 0xFFC300)
    embed1.add_field(name = "일시 점검 안내", value = "서하봇의 점검이 진행 될 예정입니다.", inline = False)
    embed1.add_field(name = "점검 시간", value = text1 +" ~ "+ text2+"까지", inline = False)
    embed1.add_field(name = "점검시 유의사항", value = "번호표, 환영멘트, 경고 등 전체 기능 일시 마비", inline = False)

    await channel.send(embed=embed)
    await channel1.send(embed=embed1)
    await channel1.send('<@&1004771045091323944>')

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
    	await ctx.send("명령어를 찾지 못했습니다")
        
################<원무과>################
@bot.slash_command(name = 'a', description = '한명의 멤버를 환영해!')
@commands.has_any_role(1004688586093887528, 1004688539914608640, 1004689605305585704, 998046067964776578)
async def a(ctx, user: discord.User):
    channel = bot.get_channel(1004742567759466536)
    await channel.send(f'<@&1005458692470222900>\n<a:sehan_4028:1008051922974023741> 저희 병원에 새로오신 환자분을 환영해주세요! :tada:\n\n<a:sehan_4019:1008051896906432582> {user.mention}님! 저희 서버에 오신걸 환영해요!\n\n<a:sehan_4019:1008051896906432582> 서버 적응이 어려우시다면 간호사를 불러주세요! :person_raising_hand:\n\n<a:sehan_4019:1008051896906432582> 문의 하실게있으시다면 <#1005166621914058782>에 편하게 문의해주세요!  :envelope_with_arrow:\n\n<a:sehan_4019:1008051896906432582> 공지는 <#1005092490061291580>에서 확인해주세요! :loudspeaker:')

@bot.slash_command(name = 'b', description = '두명의 멤버를 환영해!')
@commands.has_any_role(1004688586093887528, 1004688539914608640, 1004689605305585704, 998046067964776578)
async def b(ctx, user: discord.User, user1: discord.User):
    channel = bot.get_channel(1004742567759466536)
    await channel.send(f'<@&1005458692470222900>\n<a:sehan_4028:1008051922974023741> 저희 병원에 새로오신 환자분을 환영해주세요! :tada:\n\n<a:sehan_4019:1008051896906432582> {user.mention}, {user1.mention}님! 저희 서버에 오신걸 환영해요!\n\n<a:sehan_4019:1008051896906432582> 서버 적응이 어려우시다면 간호사를 불러주세요! :person_raising_hand:\n\n<a:sehan_4019:1008051896906432582> 문의 하실게있으시다면 <#1005166621914058782>에 편하게 문의해주세요!  :envelope_with_arrow:\n\n<a:sehan_4019:1008051896906432582> 공지는 <#1005092490061291580>에서 확인해주세요! :loudspeaker:')

@bot.slash_command(name = 'c', description = '세명의 멤버를 환영해!')
@commands.has_any_role(1004688586093887528, 1004688539914608640, 1004689605305585704, 998046067964776578)
async def c(ctx, user: discord.User, user1: discord.User, user2: discord.User):
    channel = bot.get_channel(1004742567759466536)
    await channel.send(f'<@&1005458692470222900>\n<a:sehan_4028:1008051922974023741> 저희 병원에 새로오신 환자분을 환영해주세요! :tada:\n\n<a:sehan_4019:1008051896906432582> {user.mention}, {user1.mention}, {user2.mention}님! 저희 서버에 오신걸 환영해요!\n\n<a:sehan_4019:1008051896906432582> 서버 적응이 어려우시다면 간호사를 불러주세요! :person_raising_hand:\n\n<a:sehan_4019:1008051896906432582> 문의 하실게있으시다면 <#1005166621914058782>에 편하게 문의해주세요!  :envelope_with_arrow:\n\n<a:sehan_4019:1008051896906432582> 공지는 <#1005092490061291580>에서 확인해주세요! :loudspeaker:')

@bot.slash_command(name = 'd', description = '네명의 멤버를 환영해!')
@commands.has_any_role(1004688586093887528, 1004688539914608640, 1004689605305585704, 998046067964776578)
async def d(ctx, user: discord.User, user1: discord.User, user2: discord.User, user3: discord.User):
    channel = bot.get_channel(1004742567759466536)
    await channel.send(f'<@&1005458692470222900>\n<a:sehan_4028:1008051922974023741> 저희 병원에 새로오신 환자분을 환영해주세요! :tada:\n\n<a:sehan_4019:1008051896906432582> {user.mention}, {user1.mention}, {user2.mention}, {user3.mention}님! 저희 서버에 오신걸 환영해요!\n\n<a:sehan_4019:1008051896906432582> 서버 적응이 어려우시다면 간호사를 불러주세요! :person_raising_hand:\n\n<a:sehan_4019:1008051896906432582> 문의 하실게있으시다면 <#1005166621914058782>에 편하게 문의해주세요!  :envelope_with_arrow:\n\n<a:sehan_4019:1008051896906432582> 공지는 <#1005092490061291580>에서 확인해주세요! :loudspeaker:')

@bot.slash_command(name = 'e', description = '안내중 문제가 발생한다면?')
@commands.has_any_role(1004688586093887528, 1004688539914608640, 1004689605305585704, 998046067964776578)
async def e(ctx):
    channel = bot.get_channel(1005089714266701925)

    embed = discord.Embed(title="⚠️코드블루⚠️", description = "📢<@&1004688586093887528>에서 알립니다.\n\n안내 중 문제가 발생 하였으니 보안팀은 신속히 출동 부탁드립니다.", color = 0x24008D)
    embed.add_field(name = "호출" ,value = "<@&1004688567613784175> <@&1004688539914608640> <@&998046067964776578> <@&1004689605305585704>")

    await channel.send(embed=embed)
    await channel.send("<@&1004688567613784175> <@&1004688539914608640> <@&998046067964776578> <@&1004689605305585704>")

################<간호사>################

@bot.slash_command(name = 'f', description = '한명의 멤버를 환영해!')
@commands.has_any_role(1004688954089537667, 1004688539914608640, 1004689605305585704, 998046067964776578)
async def f(ctx, user: discord.User):
    channel = bot.get_channel(1004742567759466536)
    await channel.send(f'------৹⟦ {user.mention}님 어서오세요! ⟧৹------\n\n🌹 ⟦저희 세한 병원에 오신것을 진심으로 환영합니다!⟧\n\n🌹 ⟦저는 {user.mention}님의 담당 간호사 {ctx.author.mention}입니다!⟧\n\n🌹 ⟦세한 병원에서의 적응이 어려우시다면 <@&1004688954089537667> 혹은 저를 멘션해주세요!⟧\n\n🌹 ⟦남들에게 말 못할 고민이나 서버내에서의 고민이 있으시다면 <@&1004688920694501406>에서 상담을 도와드려요!⟧\n\n🌹 ⟦편안한 병원 생활 되시길 바랍니다!⟧ ')

@bot.slash_command(name = 'g', description = '두명의 멤버를 환영해!')
@commands.has_any_role(1004688954089537667, 1004688539914608640, 1004689605305585704, 998046067964776578)
async def g(ctx, user: discord.User, user1: discord.User):
    channel = bot.get_channel(1004742567759466536)
    await channel.send(f'------৹⟦ {user.mention}, {user1.mention}님 어서오세요! ⟧৹------\n\n🌹 ⟦저희 세한 병원에 오신것을 진심으로 환영합니다!⟧\n\n🌹 ⟦저는 여러분의 담당 간호사 {ctx.author.mention}입니다!⟧\n\n🌹 ⟦세한 병원에서의 적응이 어려우시다면 <@&1004688954089537667> 혹은 저를 멘션해주세요!⟧\n\n🌹 ⟦남들에게 말 못할 고민이나 서버내에서의 고민이 있으시다면 <@&1004688920694501406>에서 상담을 도와드려요!⟧\n\n🌹 ⟦편안한 병원 생활 되시길 바랍니다!⟧ ')

@bot.slash_command(name = 'h', description = '세명의 멤버를 환영해!')
@commands.has_any_role(1004688954089537667, 1004688539914608640, 1004689605305585704, 998046067964776578)
async def h(ctx, user: discord.User, user1: discord.User, user2: discord.User):
    channel = bot.get_channel(1004742567759466536)
    await channel.send(f'------৹⟦ {user.mention}, {user1.mention}, {user2.mention}님 어서오세요! ⟧৹------\n\n🌹 ⟦저희 세한 병원에 오신것을 진심으로 환영합니다!⟧\n\n🌹 ⟦저는 여러분의 담당 간호사 {ctx.author.mention}입니다!⟧\n\n🌹 ⟦세한 병원에서의 적응이 어려우시다면 <@&1004688954089537667> 혹은 저를 멘션해주세요!⟧\n\n🌹 ⟦남들에게 말 못할 고민이나 서버내에서의 고민이 있으시다면 <@&1004688920694501406>에서 상담을 도와드려요!⟧\n\n🌹 ⟦편안한 병원 생활 되시길 바랍니다!⟧ ')

@bot.slash_command(name = 'i', description = '네명의 멤버를 환영해!')
@commands.has_any_role(1004688954089537667, 1004688539914608640, 1004689605305585704, 998046067964776578)
async def i(ctx, user: discord.User, user1: discord.User, user2: discord.User, user3: discord.User):
    channel = bot.get_channel(1004742567759466536)
    await channel.send(f'------৹⟦ {user.mention}, {user1.mention}, {user2.mention}, {user3.mention}님 어서오세요! ⟧৹------\n\n🌹 ⟦저희 세한 병원에 오신것을 진심으로 환영합니다!⟧\n\n🌹 ⟦저는 여러분의 담당 간호사 {ctx.author.mention}입니다!⟧\n\n🌹 ⟦세한 병원에서의 적응이 어려우시다면 <@&1004688954089537667> 혹은 저를 멘션해주세요!⟧\n\n🌹 ⟦남들에게 말 못할 고민이나 서버내에서의 고민이 있으시다면 <@&1004688920694501406>에서 상담을 도와드려요!⟧\n\n🌹 ⟦편안한 병원 생활 되시길 바랍니다!⟧ ')

################<보안팀>################

@bot.slash_command(name = 'k', description = '환자에게 경고를 줘!')
@commands.has_any_role(1004688567613784175, 1004688539914608640, 1004689605305585704, 998046067964776578)
async def k(ctx, user: discord.User, num, text):
    channel = bot.get_channel(1004748420898103326)
    await channel.send(f'{user.mention}||({user.id})|| 경고 {num}회 지급되었습니다.\n사유 : <#1005092364118925383> {text} 을 참고해주세요!')

@bot.slash_command(name = 'j', description = '환자에게 주의를 줘!')
@commands.has_any_role(1004688567613784175, 1004688539914608640, 1004689605305585704, 998046067964776578)
async def j(ctx, user: discord.User, num, text):
    channel = bot.get_channel(1004748420898103326)
    await channel.send(f'{user.mention}||({user.id})|| 주의 {num}회 지급되었습니다.\n사유 : <#1005092364118925383> {text} 을 참고해주세요!')

@bot.slash_command(name = 'l', description = '환자를 차단해!')
@commands.has_any_role(1004688567613784175, 1004688539914608640, 1004689605305585704, 998046067964776578)
async def l(ctx, user: discord.User, text):
    channel = bot.get_channel(1004748585629388913)
    await channel.send(f'{user.mention}||({user.id})|| 차단되었습니다.\n사유 : <#1005092364118925383> {text} 을 참고해주세요!')

################<정신과>################

@bot.slash_command(name = 'p', description = '상담 중 문제가 발생한다면?')
@commands.has_any_role(1004688920694501406, 1004688539914608640, 1004689605305585704, 998046067964776578)
async def p(ctx):
    channel = bot.get_channel(1005089714266701925)

    embed = discord.Embed(title="⚠️코드레드⚠️", description = "📢<@&1004688920694501406>에서 알립니다.\n\n상담 중 문제가 발생 하였으니 보안팀은 신속히 출동 부탁드립니다.", color = 0xA70800)
    embed.add_field(name = "호출" ,value = "<@&1004688567613784175> <@&1004688539914608640> <@&998046067964776578> <@&1004689605305585704>")

    await channel.send(embed=embed)
    await channel.send("<@&1004688567613784175> <@&1004688539914608640> <@&998046067964776578> <@&1004689605305585704>")

################<외과>################

@bot.slash_command(name = 't', description = '담당자를 올려보자!')
@commands.has_any_role(998527437237387334, 1004688539914608640, 1004689605305585704, 998046067964776578)
async def t(ctx, user: discord.User, user1: discord.User):
    await ctx.send(f'||<@&997116215224975440>||\n\n문의 : {user.mention}\n\n담당자 : {user1.mention}')

################<서하전용>################

@bot.slash_command(name = 'z', description = '원무과와 간호과의 환영멘트를 동시에!')
@commands.has_any_role(998046067964776578)
async def z(ctx, user: discord.User):
    channel = bot.get_channel(1004742567759466536)
    await channel.send(f'<@&1005458692470222900>\n<a:sehan_4028:1008051922974023741> 저희 병원에 새로오신 환자분을 환영해주세요! :tada:\n\n<a:sehan_4019:1008051896906432582> {user.mention}님! 저희 서버에 오신걸 환영해요!\n\n<a:sehan_4019:1008051896906432582> 서버 적응이 어려우시다면 간호사를 불러주세요! :person_raising_hand:\n\n<a:sehan_4019:1008051896906432582> 문의 하실게있으시다면 <#1005166621914058782>에 편하게 문의해주세요!  :envelope_with_arrow:\n\n<a:sehan_4019:1008051896906432582> 공지는 <#1005092490061291580>에서 확인해주세요! :loudspeaker:')
    await channel.send(f'------৹⟦ {user.mention}님 어서오세요! ⟧৹------\n\n🌹 ⟦저희 세한 병원에 오신것을 진심으로 환영합니다!⟧\n\n🌹 ⟦저는 {user.mention}님의 담당 간호사 {ctx.author.mention}입니다!⟧\n\n🌹 ⟦세한 병원에서의 적응이 어려우시다면 <@&1004688954089537667> 혹은 저를 멘션해주세요!⟧\n\n🌹 ⟦남들에게 말 못할 고민이나 서버내에서의 고민이 있으시다면 <@&1004688920694501406>에서 상담을 도와드려요!⟧\n\n🌹 ⟦편안한 병원 생활 되시길 바랍니다!⟧ ')

@bot.slash_command(name = '종료', description = '안전 종료!')
@commands.has_any_role(998046067964776578)
async def 종료(ctx):
    await ctx.send("안전종료 프로세스 가동")
    sys.exit("안전종료 프로세스 가동")

@bot.slash_command(name = '중지', description = '안전 종료!')
@commands.has_any_role(998046067964776578)
async def 중지(ctx):
    await ctx.send("안전종료 프로세스 가동")
    sys.exit("안전종료 프로세스 가동")

@bot.slash_command(name = '정지', description = '안전 종료!')
@commands.has_any_role(998046067964776578)
async def 정지(ctx):
    await ctx.send("안전종료 프로세스 가동")
    sys.exit("안전종료 프로세스 가동")

bot.run('OTg2MjkwODk4ODg5NDkwNTIy.Gejnls.jGdPwSgV2Xk2negGgLhtFtgiVEvCJO6xtcv7Xo')